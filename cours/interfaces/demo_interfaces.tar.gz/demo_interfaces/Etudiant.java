package demo_interfaces;

public interface Etudiant {
    static final int AGE_MINIMAL = 15; 
    int[] getNotes();
}
 
