package demo_interfaces;

public interface Affichable {
    void afficher();
}
 
