/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercice3;


import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author slam
 */
public class Proprietaire {
    
    private String nom;
    private Date dateNaissance;
    private ArrayList<Vehicule> vehicules = new ArrayList<Vehicule>();
    
    public Proprietaire(String nom, Date dateNaissance){
        this.nom = nom;
        this.dateNaissance = dateNaissance;
     
    }
    
    public void ajouter(Vehicule vehicule){
        this.vehicules.add(vehicule);
    }
    
    public void afficherVehicules(){
        for(Vehicule v: vehicules){
            System.out.println(v.afficher());
        }
    }
    
    public void afficher(){
        System.out.print(this.nom + " date de naissance : " + this.dateNaissance);
    }
    
    public String toString(){
      return (this.nom + " date de naissance : " + this.dateNaissance);
    }
}
