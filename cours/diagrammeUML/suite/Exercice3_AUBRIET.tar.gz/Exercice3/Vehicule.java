/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercice3;

/**
 *
 * @author slam
 */
public class Vehicule {
        
    private String nom;
    private String marque;
    private Proprietaire proprietaire;
    /**
     * @param args the command line arguments
     */
    public Vehicule(String nom, String marque, Proprietaire proprietaire) {
        this.nom = nom;
        this.marque = marque;
        this.proprietaire = proprietaire; 
    }
    
    public String afficher(){
        return (this.nom + " " + this.marque);
    }
    
}
