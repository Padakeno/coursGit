/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercice3;

import java.util.Date;
/**
 *
 * @author slam
 */
public class Main {
    
    public static void main(String[] args){
    
        Date date = new Date(94, 8, 16);
        Proprietaire p1 = new Proprietaire("Chloé", date);
        Moto yama = new Moto("fjr1300","Yamaha", p1);
        Vehicule v1 = new Voiture("Yaris", "Toyota", p1, 250);
        Vehicule v2 = new Vehicule("Aygo", "Toyota", p1);


        p1.ajouter(v2);
        p1.afficherVehicules();
        System.out.println(v1.afficher());
    
    }
    
}
